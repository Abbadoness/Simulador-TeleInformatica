#include "CamadaAplicacao.hpp"

using namespace std;

int main(void){
    AplicacaoTransmissora();
    return 0;
}
