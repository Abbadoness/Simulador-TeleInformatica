#include "CamadaFisica.hpp"
#include <vector>
#include <string>

using std::string;

void AplicacaoTransmissora(void);
void CamadaDeAplicacaoTransmissora(string mensagem);
void AplicacaoReceptora(string mensagem);
vector<int> StringParaASCII(string mensagem);
string ASCIIParaString(vector<int> quadro);

